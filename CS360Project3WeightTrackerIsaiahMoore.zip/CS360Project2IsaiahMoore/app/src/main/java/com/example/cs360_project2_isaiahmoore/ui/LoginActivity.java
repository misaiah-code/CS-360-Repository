package com.example.cs360_project2_isaiahmoore.ui;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.cs360_project2_isaiahmoore.R;
import com.example.cs360_project2_isaiahmoore.data.DatabaseHelper;

// LoginActivity handles user authentication.
// Allows existing users to log in and new users to register.
public class LoginActivity extends AppCompatActivity {

    // Input fields for username and password
    private EditText editUsername, editPassword;

    // Database helper used for login validation and account creation
    private DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_activity);

        // Initialize database access
        db = new DatabaseHelper(this);

        // Bind UI input fields
        editUsername = findViewById(R.id.editUsername);
        editPassword = findViewById(R.id.editPassword);

        // Login button attempts to authenticate an existing user
        Button buttonLogin = findViewById(R.id.buttonLogin);

        // Create Account button registers a new user if the username is unused
        Button buttonCreate = findViewById(R.id.buttonCreateAccount);

        buttonLogin.setOnClickListener(v -> doLogin());
        buttonCreate.setOnClickListener(v -> doCreateAccount());
    }

    // Attempts to log in an existing user by validating credentials.
    private void doLogin() {
        String u = editUsername.getText().toString();
        String p = editPassword.getText().toString();

        // Validate that required fields are not empty
        if (!validate(u, p)) return;

        // Check credentials against the database
        if (db.validateLogin(u, p)) {
            Toast.makeText(this, "Login successful.", Toast.LENGTH_SHORT).show();

            // Navigate to the dashboard screen after successful login
            startActivity(new Intent(this, WeightsActivity.class));
            finish(); // Prevent returning to login via back button
        } else {
            Toast.makeText(this, "Invalid username or password.", Toast.LENGTH_SHORT).show();
        }
    }


    //  Creates a new user account if the username does not already exist.
    private void doCreateAccount() {
        String u = editUsername.getText().toString();
        String p = editPassword.getText().toString();

        // Validate that required fields are not empty
        if (!validate(u, p)) return;

        // Prevent duplicate usernames
        if (db.userExists(u)) {
            Toast.makeText(this, "Username already exists. Try logging in.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Attempt to create the new user account
        boolean created = db.createUser(u, p);
        if (created) {
            Toast.makeText(this, "Account created. You can log in now.", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Could not create account.", Toast.LENGTH_SHORT).show();
        }
    }

    // Validates login input fields.
    private boolean validate(String u, String p) {
        if (TextUtils.isEmpty(u.trim())) {
            editUsername.setError("Username required");
            return false;
        }
        if (TextUtils.isEmpty(p)) {
            editPassword.setError("Password required");
            return false;
        }
        return true;
    }
}