package com.example.cs360_project2_isaiahmoore.models;

// WeightEntry represents a single row from the weights table.
public class WeightEntry {

    // Unique database ID for this entry
    public long id;

    // Date the weight was recorded (stored as yyyy-MM-dd)
    public String dateIso;

    // Recorded weight value
    public double weight;

    // Constructs a WeightEntry object from database values.
    public WeightEntry(long id, String dateIso, double weight) {
        this.id = id;
        this.dateIso = dateIso;
        this.weight = weight;
    }
}