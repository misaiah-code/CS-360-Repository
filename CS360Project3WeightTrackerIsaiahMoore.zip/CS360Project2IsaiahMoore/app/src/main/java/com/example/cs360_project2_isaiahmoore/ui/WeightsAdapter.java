package com.example.cs360_project2_isaiahmoore.ui;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.cs360_project2_isaiahmoore.R;
import com.example.cs360_project2_isaiahmoore.models.WeightEntry;

import java.util.ArrayList;

// WeightsAdapter binds WeightEntry data to the RecyclerView rows (row_weight.xml).
// It delegates row actions (delete/edit) back to the Activity through a listener
public class WeightsAdapter extends RecyclerView.Adapter<WeightsAdapter.VH> {

    // Listener interface used to communicate user actions on a row back to the Activity.
    public interface OnRowActionListener {
        void onDelete(WeightEntry entry);
        void onEdit(WeightEntry entry); // for Update requirement
    }

    // In-memory list of weight entries currently displayed
    private final ArrayList<WeightEntry> items = new ArrayList<>();

    // Callback implemented by the Activity to handle row actions
    private final OnRowActionListener listener;

    public WeightsAdapter(OnRowActionListener listener) {
        this.listener = listener;
    }

    // Replaces the adapter's dataset and refreshes the UI.
    public void setItems(ArrayList<WeightEntry> newItems) {
        items.clear();
        items.addAll(newItems);

        //  Refresh RecyclerView after data changes
        notifyDataSetChanged();
    }

    // Inflates the row layout and creates a ViewHolder for RecyclerView to reuse.
    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_weight, parent, false);
        return new VH(v);
    }

    // Binds a WeightEntry to an existing ViewHolder (sets text + click handlers).
    @Override
    public void onBindViewHolder(@NonNull VH holder, int position) {
        WeightEntry entry = items.get(position);

        // Display date and weight values from the model
        holder.rowDate.setText(entry.dateIso);
        holder.rowWeight.setText(String.valueOf(entry.weight));

        // DELETE: X button removes the entry
        holder.buttonDelete.setOnClickListener(v -> listener.onDelete(entry));

        // Simple UPDATE: tap the row (or long press) to edit the weight
        holder.itemView.setOnClickListener(v -> listener.onEdit(entry));
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    // ViewHolder caches row view references for performance (avoids repeated findViewById calls).
    static class VH extends RecyclerView.ViewHolder {
        TextView rowDate, rowWeight;
        Button buttonDelete;

        VH(@NonNull View itemView) {
            super(itemView);

            // Bind row UI elements
            rowDate = itemView.findViewById(R.id.rowDate);
            rowWeight = itemView.findViewById(R.id.rowWeight);
            buttonDelete = itemView.findViewById(R.id.buttonDeleteRow);
        }
    }
}