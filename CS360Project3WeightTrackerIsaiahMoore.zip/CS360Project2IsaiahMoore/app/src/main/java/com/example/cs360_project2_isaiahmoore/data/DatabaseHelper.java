package com.example.cs360_project2_isaiahmoore.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

//  DatabaseHelper manages the app's local SQLite database.
public class DatabaseHelper extends SQLiteOpenHelper {

    // Database file name and version
    private static final String DB_NAME = "weight_tracker.db";
    private static final int DB_VERSION = 1;

    // Table names
    public static final String TABLE_USERS = "users";
    public static final String TABLE_WEIGHTS = "weights";
    public static final String TABLE_GOAL = "goal";

    public DatabaseHelper(Context context) {
        // SQLiteOpenHelper manages opening/creating the database behind the scenes
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        // Users: stores login credentials (username must be unique)
        db.execSQL(
                "CREATE TABLE " + TABLE_USERS + " (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                        "username TEXT UNIQUE NOT NULL," +
                        "password TEXT NOT NULL" +
                        ");"
        );

        // Weights: stores each weight entry with a date string in yyyy-MM-dd format
        db.execSQL(
                "CREATE TABLE " + TABLE_WEIGHTS + " (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                        "date TEXT NOT NULL," +     // yyyy-MM-dd
                        "weight REAL NOT NULL" +
                        ");"
        );

        // Goal: single-row table (id is always 1) to store the user's target weight
        db.execSQL(
                "CREATE TABLE " + TABLE_GOAL + " (" +
                        "id INTEGER PRIMARY KEY," + // always 1
                        "goal_weight REAL NOT NULL" +
                        ");"
        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_WEIGHTS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_GOAL);
        onCreate(db);
    }

    // Login / Account Creation

    // Checks whether a username already exists.
    public boolean userExists(String username) {
        SQLiteDatabase db = getReadableDatabase();

        // Use parameterized queries (?) to avoid SQL injection and quoting issues
        Cursor c = db.rawQuery(
                "SELECT id FROM " + TABLE_USERS + " WHERE username=?",
                new String[]{username.trim()}
        );
        boolean exists = c.moveToFirst();
        c.close(); // Close Cursor to prevent memory/resource leaks
        return exists;
    }

    // Creates a new user account and stores credentials in the users table.
    public boolean createUser(String username, String password) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("username", username.trim());
        cv.put("password", password);
        long result = db.insert(TABLE_USERS, null, cv);
        return result != -1;
    }

    // Validates a login attempt by checking for a matching username/password row.
    public boolean validateLogin(String username, String password) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery(
                "SELECT id FROM " + TABLE_USERS + " WHERE username=? AND password=?",
                new String[]{username.trim(), password}
        );
        boolean ok = c.moveToFirst();
        c.close();
        return ok;
    }

    // Goal (single-row UPSERT)

    // Saves the user's goal weight.
    public boolean setGoalWeight(double goalWeight) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("id", 1);
        cv.put("goal_weight", goalWeight);

        // Update first (row exists if user previously set a goal)
        int updated = db.update(TABLE_GOAL, cv, "id=1", null);

        // If no row existed, insert the single goal record
        if (updated == 0) {
            long inserted = db.insert(TABLE_GOAL, null, cv);
            return inserted != -1;
        }
        return true;
    }

    // Retrieves the goal weight if it exists.
    public Double getGoalWeightOrNull() {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT goal_weight FROM " + TABLE_GOAL + " WHERE id=1", null);
        Double goal = null;
        if (c.moveToFirst()) {
            goal = c.getDouble(0);
        }
        c.close();
        return goal;
    }

    // Weights CRUD

    // CREATE: Adds a new weight entry for a given date.
    public long addWeight(String dateIso, double weight) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("date", dateIso);
        cv.put("weight", weight);
        return db.insert(TABLE_WEIGHTS, null, cv);
    }

    // READ: Returns a Cursor over all weight entries (newest first).
    public Cursor getAllWeights() {
        SQLiteDatabase db = getReadableDatabase();
        return db.rawQuery(
                "SELECT id, date, weight FROM " + TABLE_WEIGHTS + " ORDER BY date DESC",
                null
        );
    }

    // DELETE: Removes a weight entry by its primary key ID.
    public boolean deleteWeight(long id) {
        SQLiteDatabase db = getWritableDatabase();
        int rows = db.delete(TABLE_WEIGHTS, "id=?", new String[]{String.valueOf(id)});
        return rows > 0;
    }

    // UPDATE: Updates the weight value for an existing entry.
    public boolean updateWeight(long id, double newWeight) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("weight", newWeight);
        int rows = db.update(TABLE_WEIGHTS, cv, "id=?", new String[]{String.valueOf(id)});
        return rows > 0;
    }
}