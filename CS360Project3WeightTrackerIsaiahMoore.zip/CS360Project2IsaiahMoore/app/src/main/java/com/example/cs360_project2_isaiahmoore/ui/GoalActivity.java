package com.example.cs360_project2_isaiahmoore.ui;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.cs360_project2_isaiahmoore.R;
import com.example.cs360_project2_isaiahmoore.data.DatabaseHelper;
import com.google.android.material.appbar.MaterialToolbar;

// GoalActivity allows the user to set (or update) their goal weight.
// The value is stored persistently in the local SQLite database so it remains
// available after the app is closed and reopened.
public class GoalActivity extends AppCompatActivity {

    // Database helper used to save and retrieve the goal weight
    private DatabaseHelper db;

    // Input field where the user enters their goal weight
    private EditText editGoalWeight;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.goal_activity);

        // Initialize database access and connect UI elements to code
        db = new DatabaseHelper(this);
        editGoalWeight = findViewById(R.id.editGoalWeight);

        // Back arrow returns to the previous screen without saving changes
        MaterialToolbar topAppBar = findViewById(R.id.topAppBar);
        topAppBar.setNavigationOnClickListener(v -> finish());

        // Save button validates input and stores the goal weight in the database
        Button buttonSaveGoal = findViewById(R.id.buttonSaveGoal);
        buttonSaveGoal.setOnClickListener(v -> saveGoal());
    }

    // Validates the goal weight field and saves the goal value to the database.
    private void saveGoal() {
        String s = editGoalWeight.getText().toString();

        // Basic validation: user must enter something
        if (TextUtils.isEmpty(s.trim())) {
            editGoalWeight.setError("Enter a goal weight");
            return;
        }

        // Parse numeric goal value
        double goal;
        try {
            goal = Double.parseDouble(s);
        } catch (NumberFormatException e) {
            editGoalWeight.setError("Invalid number");
            return;
        }

        // Persist goal weight to SQLite; show feedback and return to dashboard
        if (db.setGoalWeight(goal)) {
            Toast.makeText(this, "Goal saved.", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            Toast.makeText(this, "Could not save goal.", Toast.LENGTH_SHORT).show();
        }
    }
}