package com.example.cs360_project2_isaiahmoore.ui;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.cs360_project2_isaiahmoore.R;
import com.example.cs360_project2_isaiahmoore.data.DatabaseHelper;
import com.example.cs360_project2_isaiahmoore.models.WeightEntry;
import com.example.cs360_project2_isaiahmoore.utils.SmsUtils;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

// WeightsActivity is the main dashboard screen.
public class WeightsActivity extends AppCompatActivity {

    // Database helper provides persistent storage (SQLite)
    private DatabaseHelper db;

    // RecyclerView adapter for displaying weight history
    private WeightsAdapter adapter;

    // UI elements used on the dashboard
    private TextView textGoal;
    private EditText editWeight;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.weights_activity);

        // Initialize database access
        db = new DatabaseHelper(this);

        // Bind UI elements
        textGoal = findViewById(R.id.textGoal);
        editWeight = findViewById(R.id.editWeight);

        Button buttonAddWeight = findViewById(R.id.buttonAddWeight);
        Button buttonSetGoal = findViewById(R.id.buttonSetGoal);
        Button buttonNotifications = findViewById(R.id.buttonNotifications);

        // Setup RecyclerView (LinearLayoutManager displays rows in a vertical list)
        RecyclerView recycler = findViewById(R.id.recyclerWeights);
        recycler.setLayoutManager(new LinearLayoutManager(this));

        // Adapter handles row rendering and row-level actions (delete / edit)
        adapter = new WeightsAdapter(new WeightsAdapter.OnRowActionListener() {
            @Override
            public void onDelete(WeightEntry entry) {
                // DELETE: remove the selected row from the database
                if (db.deleteWeight(entry.id)) {
                    Toast.makeText(WeightsActivity.this, "Entry deleted.", Toast.LENGTH_SHORT).show();
                    refreshList();
                }
            }

            @Override
            public void onEdit(WeightEntry entry) {
                // UPDATE: edit selected entry
                showEditDialog(entry);
            }
        });

        recycler.setAdapter(adapter);

        // CREATE: add a new entry when user taps Add Entry
        buttonAddWeight.setOnClickListener(v -> addEntry());

        // Navigation to supporting screens
        buttonSetGoal.setOnClickListener(v -> startActivity(new Intent(this, GoalActivity.class)));
        buttonNotifications.setOnClickListener(v -> startActivity(new Intent(this, NotificationActivity.class)));
    }

    @Override
    protected void onResume() {
        super.onResume();

        // Refresh goal and list when returning from other screens (Goal/Notifications)
        refreshGoalText();
        refreshList();
    }

    // Displays the current goal weight on the dashboard.
    private void refreshGoalText() {
        Double goal = db.getGoalWeightOrNull();
        textGoal.setText(goal == null ? "Goal Weight: Not Set" : "Goal Weight: " + goal);
    }

    // READ: Loads all entries from the database and displays them in the RecyclerView.
    private void refreshList() {
        ArrayList<WeightEntry> items = new ArrayList<>();
        Cursor c = db.getAllWeights();
        while (c.moveToNext()) {
            long id = c.getLong(0);
            String dateIso = c.getString(1);
            double weight = c.getDouble(2);
            items.add(new WeightEntry(id, dateIso, weight));
        }
        c.close();
        adapter.setItems(items);
    }

    // CREATE: Validates input, inserts a new weight entry for today's date,
    // refreshes the list, then checks whether the goal was reached.
    private void addEntry() {
        String s = editWeight.getText().toString();

        // Validate input before attempting to store it
        if (TextUtils.isEmpty(s.trim())) {
            editWeight.setError("Enter today's weight");
            return;
        }

        double weight;
        try {
            weight = Double.parseDouble(s);
        } catch (NumberFormatException e) {
            editWeight.setError("Invalid number");
            return;
        }

        // Store date as yyyy-MM-dd for consistency and sorting
        String todayIso = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());

        long id = db.addWeight(todayIso, weight);
        if (id != -1) {
            editWeight.setText("");
            Toast.makeText(this, "Entry added.", Toast.LENGTH_SHORT).show();
            refreshList(); // update UI
            checkGoalAndMaybeSms(weight); // optional notification
        } else {
            Toast.makeText(this, "Could not add entry.", Toast.LENGTH_SHORT).show();
        }
    }

    // UPDATE: Displays a dialog that allows the user to edit an existing weight entry.
    private void showEditDialog(WeightEntry entry) {
        final EditText input = new EditText(this);

        // Limit input to decimal numbers only
        input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);
        input.setText(String.valueOf(entry.weight));

        new AlertDialog.Builder(this)
                .setTitle("Update Weight")
                .setMessage("Edit the weight value for " + entry.dateIso)
                .setView(input)
                .setPositiveButton("Save", (dialog, which) -> {
                    String s = input.getText().toString();
                    try {
                        double newWeight = Double.parseDouble(s);
                        if (db.updateWeight(entry.id, newWeight)) {
                            Toast.makeText(this, "Entry updated.", Toast.LENGTH_SHORT).show();
                            refreshList();
                            checkGoalAndMaybeSms(newWeight);
                        } else {
                            Toast.makeText(this, "Update failed.", Toast.LENGTH_SHORT).show();
                        }
                    } catch (NumberFormatException e) {
                        Toast.makeText(this, "Invalid number.", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    // Checks whether the user's current weight is at/near the goal weight.
    private void checkGoalAndMaybeSms(double currentWeight) {
        Double goal = db.getGoalWeightOrNull();
        if (goal == null) return;

        // Treat goal as a target weight (works for both bulking and cutting)
        double tolerance = 0.5; // pounds (or kg)
        boolean reached = Math.abs(currentWeight - goal) <= tolerance;

        // Only send SMS if goal reached AND permission granted
        if (reached && SmsUtils.canSendSms(this)) {
            SmsUtils.sendGoalReachedSms(this,
                    "Nice! You're at your goal weight (" + goal + ").");
            }
        }
    }
