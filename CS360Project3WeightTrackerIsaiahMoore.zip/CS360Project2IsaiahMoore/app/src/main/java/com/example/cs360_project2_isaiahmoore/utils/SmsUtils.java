package com.example.cs360_project2_isaiahmoore.utils;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;
import android.widget.Toast;

import androidx.core.content.ContextCompat;

// SmsUtils provides helper methods for sending SMS messages.
public class SmsUtils {

    // For emulator testing: run 2 emulators (5554 and 5556) and send to the other.
    private static final String TEST_PHONE_NUMBER = "5556";

    // Checks whether the SEND_SMS permission is granted.
    public static boolean canSendSms(Context context) {
        return ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
    }

    // Sends a goal-reached SMS message if permission is granted.
    public static void sendGoalReachedSms(Context context, String message) {
        // Do nothing if the user has not granted SMS permission
        if (!canSendSms(context)) return;

        try {
            // Send SMS message to the test number (emulator)
            SmsManager.getDefault().sendTextMessage(TEST_PHONE_NUMBER, null, message, null, null);
            Toast.makeText(context, "SMS sent (emulator).", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            // Catch errors to prevent SMS failures from crashing the app
            Toast.makeText(context, "SMS failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
}