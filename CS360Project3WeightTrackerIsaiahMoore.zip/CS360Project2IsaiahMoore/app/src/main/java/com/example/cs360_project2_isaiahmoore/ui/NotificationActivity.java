package com.example.cs360_project2_isaiahmoore.ui;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.example.cs360_project2_isaiahmoore.R;
import com.google.android.material.appbar.MaterialToolbar;

// NotificationActivity allows the user to enable or disable SMS notifications.
public class NotificationActivity extends AppCompatActivity {

    // Displays the current SMS permission status to the user
    private TextView textPermissionStatus;

    // Toggle used to enable or disable SMS notifications
    private Switch switchEnable;

    // Handles runtime permission requests using the Activity Result API
    private ActivityResultLauncher<String> permissionLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.notification_activity);

        // Back arrow returns the user to the previous screen
        MaterialToolbar topAppBar = findViewById(R.id.topAppBar);
        topAppBar.setNavigationOnClickListener(v -> finish());

        // Bind UI elements
        textPermissionStatus = findViewById(R.id.textPermissionStatus);
        switchEnable = findViewById(R.id.switchEnableNotifications);

        // Register permission launcher to request SMS permission at runtime.
        permissionLauncher = registerForActivityResult(
                new ActivityResultContracts.RequestPermission(),
                granted -> {
                    // Update UI text whenever the permission result is returned
                    updatePermissionText();

                    if (!granted) {
                        // App continues to function
                        switchEnable.setChecked(false);
                        Toast.makeText(this, "Permission denied. App works without SMS.", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(this, "SMS permission granted.", Toast.LENGTH_SHORT).show();
                    }
                }
        );

        // Display initial permission status when the screen loads
        updatePermissionText();

        // Toggle behavior
        switchEnable.setOnCheckedChangeListener((btn, checked) -> {
            if (!checked) {
                Toast.makeText(this, "SMS notifications disabled.", Toast.LENGTH_SHORT).show();
                return;
            }

            // Only request permission if it has not already been granted
            if (hasSmsPermission()) {
                Toast.makeText(this, "SMS notifications enabled.", Toast.LENGTH_SHORT).show();
            } else {
                permissionLauncher.launch(Manifest.permission.SEND_SMS);
            }
        });
    }

    // Checks whether SMS permission has already been granted.
    private boolean hasSmsPermission() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
    }

    // Updates the on-screen permission status text for user clarity.
    private void updatePermissionText() {
        textPermissionStatus.setText(
                hasSmsPermission() ? "SMS Permission Status: Granted" : "SMS Permission Status: Not Granted"
        );
    }
}